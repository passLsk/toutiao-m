<template>
  <div>问答</div>
</template>

<script>
export default {
  data () {
    return {}
  }
}
</script>

<style scoped>
</style>
