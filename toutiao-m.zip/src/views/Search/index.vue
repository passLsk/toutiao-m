<template>
  <div>
    <form action="/">
      <van-search
        v-model="searchText"
        show-action
        placeholder="请输入搜索关键词"
        @cancel="$router.back()"
        @search="isSearch = true"
        autofocus
        @focus="isSearch=false"
      />
    </form>
    <SearchHistory v-if="searchText === ''"></SearchHistory>
    <template v-else>
      <SearchSuggest v-if="isSearch===false"
      :searchText="searchText"></SearchSuggest>
      <SearchResult v-else></SearchResult>
    </template>
  </div>
</template>

<script>
import SearchHistory from './components/SearchHistory.vue'
import SearchSuggest from './components/SearchSuggest.vue'
import SearchResult from './components/SearchResult.vue'
export default {
  created () { },
  data () {
    return {
      searchText: '',
      isSearch: false // 默认没有按下回车
    }
  },
  methods: {},
  computed: {},
  watch: {},
  filters: {},
  components: { SearchHistory, SearchSuggest, SearchResult }
}
</script>

<style scoped lang='less'>
.van-search {
  background-color: skyblue;
}
</style>
