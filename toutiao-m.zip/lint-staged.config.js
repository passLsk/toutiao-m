module.exports = {
  '*.{js,jsx,vue}': 'vue-cli-service lint'
}
